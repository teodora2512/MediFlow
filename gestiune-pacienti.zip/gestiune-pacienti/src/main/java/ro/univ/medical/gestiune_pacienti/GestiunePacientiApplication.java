package ro.univ.medical.gestiune_pacienti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestiunePacientiApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestiunePacientiApplication.class, args);
	}

}
